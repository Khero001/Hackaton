import "./Banner.css";
function Banner (){
    const iframeSrc= 'index.html'
    return <div className="container-banner" id="banner-section"> 

                <iframe className="banner-iframe"
                src="./Particle/iframe.html"
                width="100%"
                scrolling="no"
                >    
                </iframe> 
                <div className="texto-superpuesto">
                    <h1>
                        Immersed in the sounds of space
                    </h1>
                    <p>
                    With each passing moment, the celestial symphony of the cosmos surrounded me, 
                    enveloping my senses and making me feel like a mere observer in the grandeur of the universe
                    </p>
                </div> 

            </div>
}
export default Banner