import "./Cabecera.css";
function Cabecera (){
    return <header className="header">
            <div className="container-header">
                <div className="logo-div">
                    <img src="/img/logo3.jpg" alt="logo"></img>
                </div>
                <div className="container-nav">
                    <nav className="navigation">
                        <div className="list">
                            <ul>
                                <li><a href="#banner-section" className="link">HOME</a></li>
                                <li><a href="#section-solution" className="link">SOLUTIONS</a></li>
                                <li><a href="#section-about" className="link">ABOUT</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
                
            </div>
        </header>
}
export default Cabecera