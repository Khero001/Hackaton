import React, { useState } from 'react';
import AudioPlayer from 'react-audio-player';

const Carousel = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const images = ['/img/imagen (2).png', '/img/imagen (2).png']; // Reemplaza con tus rutas de imágenes
  const audioFiles = ['/music/estrellas5novena.mp3', '/music/estrellas5novena.mp3']; // Reemplaza con tus rutas de archivos de audio

  const handleAudioPlay = (audioFile) => {
    // Función para reproducir el audio seleccionado
    const audioPlayer = document.getElementById('audio-player');
    audioPlayer.src = audioFile;
    audioPlayer.play();
  };

  return (
    <div >
      <div className="image-container" id='section-solution'>
        <img src={images[currentImageIndex]} alt={`Imagen ${currentImageIndex + 1}`} />
      </div>
      <div className="audio-buttons">
        {audioFiles.map((audioFile, index) => (
          <button
            key={index}
            onClick={() => handleAudioPlay(audioFile)}
          >
            Reproducir Audio {index + 1}
          </button>
        ))}
      </div>
      <AudioPlayer id="audio-player" />
    </div>
  );
};

export default Carousel;
