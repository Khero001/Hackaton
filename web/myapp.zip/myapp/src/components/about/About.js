import "./About.css"
function About(){
    return <div className="container-about" id="section-about">
        
            <iframe className="about-iframe"
            src="./ParticleDown/iframe.html"
            width="100%"
            scrolling="no">
            </iframe>
        <div className="container-info">
            <div className="image-about">
                <img src= "/img/nasa-space-apps.png"></img>
            </div>
            <div className="info-about">
                <h2>
                    About the challenge
                </h2>
                <p>
                Your challenge is to design a method to create sonifications of 3D NASA space datasets.
                 What are some ways that 3D data cubes could be converted into sounds to convey 
                 the richness of the data? If you want to create a 3D sonification fly-through, 
                 how can you convert the video image into sounds that accurately represent what 
                 is in the visualization?Your challenge is to design a method to create sonifications 
                 of 3D NASA space datasets. What are some ways that 3D data cubes could be converted 
                 into sounds to convey the richness of the data? If you want to create a 3D sonification
                  fly-through, how can you convert the video image into sounds that accurately represent
                   what is in the visualization?
                </p>
            </div>
        </div>
        
    </div>
}

export default About