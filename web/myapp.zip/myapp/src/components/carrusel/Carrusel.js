import React, { useState, useEffect } from 'react';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import { Howl } from 'howler';
import "./Carrusel.css"
const ImageCarousel = () => {
  const [reproduciendo, setReproduciendo] = useState(false);
  const [sound, setSound] = useState(null);
  const pistasDeAudio = [
    { imagen: '/img/imagen (2).png', musica: 'galaxias0primera.mp3' },
    { imagen: '/img/imagen (1).png', musica: 'estrellas5novena.mp3' }, // Cambia el nombre de la canción si es diferente
  ];

  const handlePlayPause = (audio_str) => {
    if (sound && reproduciendo) {
      sound.pause();
    } else {
      const newSound = new Howl({
        src: [audio_str],
        onend: () => {
          setReproduciendo(false);
        },
      });
      newSound.play();
      setSound(newSound);
    }
    setReproduciendo(!reproduciendo);
  };

  return (
    <div  id='section-solution'>
      <Carousel  showThumbs={false} autoPlay={true} interval={3000} infiniteLoop={true}>
        {pistasDeAudio.map((pista, index) => (
          <div key={index}>
            <img className='imageCarrusel' src={pista.imagen} alt={`Imagen ${index + 1}`} />
            <button className={reproduciendo ? 'playing' : ''} onClick={() => handlePlayPause(`/music/${pista.musica}`)}>
              {reproduciendo ? '' : ''}
            </button>
          </div>
        ))}
      </Carousel>
    </div>
  );
};

export default ImageCarousel;
