import "./Footer.css"
function Footer(){
    return <div className="container-footer">
        <p>
            NASA Space Apps Hackaton 2023
        </p>
    </div>
}
export default Footer