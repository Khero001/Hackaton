import React, { useState } from 'react';
import { Howl, Howler } from 'howler';
import "./prueba.css"
 

const ReproductorMusica = () => {
  const [reproduciendo, setReproduciendo] = useState(false);
  const [sound, setSound] = useState(null);


 
  const handlePlayPause = () => {
    if (sound && reproduciendo) {
      // Pausar la reproducción si la instancia de Howl existe y está reproduciendo
      sound.pause();
    } else {
      // Iniciar la reproducción si no se está reproduciendo o si no hay una instancia de Howl
      const newSound = new Howl({
        src: ['/music/cancion1.mp3'], // Reemplaza con la ruta de tu canción
        onend: () => {
          setReproduciendo(false);
        },
      });
      newSound.play();
      setSound(newSound);
    }
    setReproduciendo(!reproduciendo);
  };
 

  return (
<div>
<img
        src="/img/imagen (1).png" // Reemplaza con la ruta de tu imagen
        alt="Descripción de la imagen"
        style={{ maxWidth: '100%', height: 'auto' }}
      />
<button onClick={handlePlayPause}>
        {reproduciendo ? 'Pausar' : 'Reproducir'}
</button>
</div>
  );
};

 

export default ReproductorMusica;