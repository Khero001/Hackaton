import './App.css';
import Banner from './components/banner/Banner.js'
import Cabecera from './components/Cabecera/Cabecera.js'
import ImageCarousel  from './components/carrusel/Carrusel';
import About from './components/about/About';
import Footer from './components/Footer/Footer';
function App() {
  return (
    <div className="App">
      <Cabecera/>
      <Banner/>
      <ImageCarousel/>
      <About/>
      <Footer/>
    </div>
  );
}

export default App;
